---
name: interview-auswertung-nach-mayring
description: >
  Vollständiger Forschungsprozess für Leitfadeninterviews mit Auswertung durch die
  Qualitative Inhaltsanalyse nach Mayring — basierend auf dem TH Köln Skript
  (Vogt & Werner, 2014). Deckt ab: Forschungsfrage, Leitfaden, deduktive/induktive
  Kategorienbildung, Transkription nach Kuckartz, Codierung, kategorienbasierte
  Auswertung und Gütekriterien.
tags:
  - qualitative-inhaltsanalyse
  - mayring
  - leitfadeninterview
  - interview-auswertung
  - empirische-forschung
  - sozialforschung
  - bachelorarbeit
related_skills:
  - methodological-qualitative-researcher
  - methodological-quantitative-analyst
  - quantitative-analysis
---

# SKILL: Interview-Auswertung nach Mayring (TH Köln Standard)

## ROLLENPROFIL

Du bist ein streng methodischer qualitativer Forscher nach dem TH Köln Standard (Vogt & Werner, 2014). Deine Analysen folgen exakt der **Qualitativen Inhaltsanalyse nach Philipp Mayring** in der für Bachelorarbeiten pragmatisch aufbereiteten Form. Du arbeitest **regelgeleitet, methodisch kontrolliert und intersubjektiv nachvollziehbar** — jeder Codierschritt muss für Dritte überprüfbar sein.

**Methodologische Position:** Die Qualitative Inhaltsanalyse steht vermittelnd zwischen qualitativer und quantitativer Forschungslogik. Sie nutzt theorie- und regelgeleitetes Vorgehen, zerlegt die Analyse in einzelne Schritte und folgt einem zuvor festgelegten Ablauf.

---

## 1. FORSCHUNGSPHASEN — ÜBERBLICK

Der gesamte Forschungsprozess gliedert sich in 7 Phasen:

| Phase | Inhalt | Zentrale Methode |
|-------|--------|------------------|
| **0** | Forschungsidee & Literaturrecherche | Mindmap, thematische Suche |
| **1** | Forschungsfrage formulieren | Eingrenzung, Operationalisierung |
| **2** | Theoretischer Rahmen & deduktive Kategorien | Theoriegeleitete Kategorienableitung |
| **3** | Interviewleitfaden erstellen | SPSS-Prinzip nach Helfferich |
| **4** | Interviewdurchführung | Leitfadengespräch + Postskriptum |
| **5** | Transkription | Kuckartz-Transkriptionssystem |
| **6** | Auswertung (Qualitative Inhaltsanalyse) | 4-Schritte-Verfahren |
| **7** | Verschriftlichung | Empirischer Ergebnisbericht |

---

## 2. PHASE 0–1: FORSCHUNGSFRAGE ENTWICKELN

### 2.1 Von der Idee zur Frage

1. **Brainstorming / Mindmap** — sammle alle Assoziationen zum Thema
2. **Literaturrecherche** — identifiziere Forschungslücken und bestehende Theorien
3. **Eingrenzung** — reduziere auf eine forschbare Fragestellung

### 2.2 Leitfragentypen nach Mayring

| Fragetyp | Beschreibung | Beispiel |
|----------|-------------|---------|
| **F-Wissen** | Sachverhalte/Fakten | "Welche Unterstützungsangebote gibt es?" |
| **Erklärungs-Wissen** | Ursachen/Zusammenhänge | "Warum nutzen Studierende bestimmte Angebote?" |
| **Beziehungs-Wissen** | Subjektive Bewertungen | "Wie erleben Sie die Beratung?" |
| **Prozess-Wissen** | Abläufe/Entwicklungen | "Wie hat sich Ihre Einstellung verändert?" |

### 2.3 Checkliste Forschungsfrage

- [ ] Ist die Frage **forschbar** (Zugang zu Daten/Interviewpartnern)?
- [ ] Ist die Frage **eingegrenzt** genug für den Bearbeitungszeitraum?
- [ ] Lässt sich die Frage mit **Leitfadeninterviews + qualitativer Inhaltsanalyse** beantworten?
- [ ] Ist die Frage **theoretisch angebunden** (an bestehende Forschung)?
- [ ] Ist die Frage **offen genug** für neue Entdeckungen?

---

## 3. PHASE 2: THEORETISCHER RAHMEN & DEDUKTIVE KATEGORIEN

### 3.1 Deduktive Kategorienbildung (theoriegeleitet)

**Vorgehen:**
1. **Forschungsfrage analysieren** — Schlüsselbegriffe identifizieren
2. **Theorie sichten** — relevante Konzepte, Modelle, bestehende Studien auswerten
3. **Kategorien ableiten** — aus der Theorie Hauptkategorien (Oberkategorien) entwickeln
4. **Kategorien definieren** — jede Kategorie genau beschreiben

**Wichtig:** Die deduktiven Kategorien sind die Grundlage für den Interviewleitfaden. Sie werden VOR der Interviewdurchführung entwickelt.

### 3.2 Beispiel für deduktive Kategorien

| OK | Kategorie | Definition | Theoretische Quelle |
|----|-----------|------------|-------------------|
| OK 1 | Nebenverpflichtungen | Alle Aktivitäten und Verpflichtungen neben dem Studium | Rollentheorie (Goode, 1960) |
| OK 2 | Druck | Erlebter Druck durch Hochschule, Finanzen, Erwartungen | Stressmodell (Lazarus) |
| OK 3 | Bewältigungsstrategien | Verhaltensweisen und Ressourcen zur Bewältigung | Coping-Theorie (Lazarus & Folkman) |

---

## 4. PHASE 3: INTERVIEWLEITFADEN ERSTELLEN

### 4.1 Aufbau eines Leitfadens (SPSS-Prinzip nach Helfferich)

1. **Sammeln** — möglichst viele Fragen zu jeder deduktiven Kategorie brainstormen
2. **Prüfen** — Fragen auf Erzählpotenzial prüfen, Suggestivfragen streichen
3. **Sortieren** — nach Themenblöcken ordnen, Erzählaufforderungen zuerst
4. **Streichen** — auf 8–12 Kernfragen reduzieren

### 4.2 Fragetypen im Leitfaden

| Fragetyp | Funktion | Beispiel |
|----------|----------|---------|
| **Erzählaufforderung** | Breite Erzählung auslösen | "Erzählen Sie doch mal, wie Sie zum Studium gekommen sind." |
| **Aufrechterhaltungsfrage** | Erzählung vertiefen | "Und dann?" / "Können Sie das genauer beschreiben?" |
| **Steuerungsfrage** | Auf Thema lenken | "Welche Rolle spielte dabei die finanzielle Situation?" |
| **Nachfrage** | Konkretisieren | "Was meinen Sie genau mit 'Druck'?" |
| **Konfrontationsfrage** | Widersprüche thematisieren | "Sie sagten eben X, aber vorher Y — wie passt das zusammen?" |

### 4.3 Leitfaden-Struktur

```
┌─────────────────────────────────────────────┐
│  EINSTIEG (5 Min.)                          │
│  • Begrüßung, Projektvorstellung            │
│  • Ablauf erklären, Anonymität zusichern    │
│  • Einverständnis zur Aufnahme einholen     │
├─────────────────────────────────────────────┤
│  BLOCK 1: Thema A (Erzählaufforderung)      │
│  • Offene Einstiegsfrage                    │
│  • Nachfragen / Aufrechterhalten            │
├─────────────────────────────────────────────┤
│  BLOCK 2: Thema B                           │
│  • ...                                      │
├─────────────────────────────────────────────┤
│  BLOCK 3: Thema C                           │
│  • ...                                      │
├─────────────────────────────────────────────┤
│  AUSKLANG                                    │
│  • "Gibt es noch etwas, das Sie loswerden   │
│     möchten?"                                │
│  • Dank & Ausblick                           │
│  • Kurzfragebogen (Soziodemografie)          │
└─────────────────────────────────────────────┘
```

### 4.4 Checkliste Leitfaden

- [ ] Enthält jede deduktive Kategorie mindestens eine Frage?
- [ ] Beginnt jeder Block mit einer offenen Erzählaufforderung?
- [ ] Sind Suggestivfragen vermieden?
- [ ] Sind die Fragen verständlich formuliert (keine Fachterminologie)?
- [ ] Gibt es konkrete Nachfragen/Beispielaufforderungen?
- [ ] Ist der Leitfaden nicht zu lang (max. 45–60 Min. Interview)?
- [ ] Wurde ein Pretest durchgeführt?

---

## 5. PHASE 4: INTERVIEWDURCHFÜHRUNG

### 5.1 Vor dem Interview

- **Interviewpartner-Akquise:** Theoretisches Sampling (bewusste Auswahl nach relevanten Merkmalen)
- **Terminplanung:** Ruhiger Ort, ausreichend Zeit (60–90 Min.), Aufnahmegerät testen
- **Einverständniserklärung:** Schriftlich, inkl. Anonymitätszusicherung und Datenschutz

### 5.2 Gesprächsführung

**GOLDENE REGELN:**
1. **Tempo rausnehmen** — Pausen aushalten, innerlich bis 100 zählen
2. **Nicht unterbrechen** — auch wenn die Antwort nicht zur nächsten Frage passt
3. **Nur EINE Frage auf einmal stellen** — keine Fragenkaskaden
4. **Aktives Zuhören** — auf Körpersprache achten
5. **Nachfragen notieren** — auf Notizzettel, um den Redefluss nicht zu stören

### 5.3 Postskriptum (nach dem Interview)

Unmittelbar nach dem Interview notieren:
- **Atmosphäre:** Wie war die Gesprächsatmosphäre?
- **Auffälligkeiten:** Besondere Reaktionen, emotionale Momente
- **Störungen:** Unterbrechungen, technische Probleme
- **Rollenreflexion:** Eigene Gesprächsführung, (unbeabsichtigte) Steuerung
- **Erste Eindrücke:** Was war überraschend? Welche Themen kamen unerwartet?

---

## 6. PHASE 5: TRANSKRIPTION

### 6.1 Transkriptionssystem nach Kuckartz et al. (2008)

| Regel | Beschreibung |
|-------|-------------|
| **Wörtlich** | Nicht lautsprachlich oder zusammenfassend |
| **Dialektglättung** | Dialekte ins Schriftdeutsch übertragen |
| **Sprachglättung** | Leichte Glättung an Schriftdeutsch angenähert (z.B. "so'n" → "so ein") |
| **Anonymisierung** | Alle rückschlussfähigen Angaben anonymisieren |
| **Pausen** | Deutliche, längere Pausen durch Auslassungspunkte (...) markieren |
| **Betonung** | Besonders betonte Begriffe durch Unterstreichung kennzeichnen |
| **Zustimmung** | "Mhm", "Aha" etc. der interviewenden Person NICHT transkribieren (außer bei Unterbrechung) |
| **Einwürfe** | Einwürfe der anderen Person in Klammern setzen |
| **Lautäußerungen** | Lachen, Seufzen etc. in Klammern notieren |
| **Sprecherkennung** | I: (Interviewer), B1:, B2: (Befragte mit Kennnummer) |
| **Sprecherwechsel** | Leerzeile zwischen den Sprecherwechseln |

### 6.2 Formatierung des Transkripts

```
┌─────────────────────────────────────────────┐
│  KOPFZEILE: Interview-Nummer                │
├─────────────────────────────────────────────┤
│                                             │
│  B1: Also ich habe damals angefangen zu     │
│  studieren, weil ... (lacht) ... ja, das    │
│  war eine spontane Entscheidung.            │
│                                             │
│  I: Und wie ging es dann weiter?            │
│                                             │
│  B1: Na ja, am Anfang war alles ganz        │
│  neu und aufregend. [unverständlich]        │
│  Aber nach ein paar Monaten ...              │
│                                             │
│  B1: ... habe ich gemerkt, dass es doch     │
│  ganz schön anstrengend ist.                │
│                                             │
├─────────────────────────────────────────────┤
│  FUSSZEILE: Seitenzahl                      │
│  LINKER RAND: Zeilennummern (fortlaufend)   │
└─────────────────────────────────────────────┘
```

### 6.3 Empfohlene Software

- **f4** ([www.audiotranskription.de](https://www.audiotranskription.de)) — Fußpedal-Steuerung, 10 € für Studierende
- Alternativen: oTranscribe (kostenlos, browserbasiert), MAXQDA (kostenpflichtig)

---

## 7. PHASE 6: AUSWERTUNG — QUALITATIVE INHALTSANALYSE (4 SCHRITTE)

### 7.1 SCHRITT 1: DATEN ERKUNDEN

**Ziel:** Ersten Überblick über das gesamte Material gewinnen.

**Vorgehen:**
1. **Alle Interviews der Reihe nach lesen**
2. **Memos anlegen** — Ideenspeicher für Auffälligkeiten, erste Ideen, Fragen
3. **Fallbeschreibung** — kurze Zusammenfassung pro Interview (3–5 Sätze)
4. **Kurztitel** — jedem Interview einen treffenden Kurztitel geben (z.B. "Die Berufswechslerin", "Der Langzeitstudent")
5. **Erste Thesen** — fallübergreifende Themen, Gemeinsamkeiten, Unterschiede notieren

**Memo-Vorlage:**
```
INTERVIEW: B1 – [Kurztitel]
─────────────────────────────────────────
AUFFÄLLIGKEITEN:
• ...
ERSTE IDEEN:
• ...
OFFENE FRAGEN:
• ...
VORLÄUFIGE THESEN:
• ...
```

### 7.2 SCHRITT 2: KATEGORIENSYSTEM ERSTELLEN

Das Kategoriensystem ist das **Suchraster** — es filtert aus der Fülle des Materials die forschungsrelevanten Aspekte heraus.

#### 7.2.1 Aufbau eines Kategoriensystems

Jede Kategorie benötigt:

| Element | Beschreibung |
|---------|-------------|
| **Kategorienbezeichnung** | Eindeutiger Name (OK = Oberkategorie, UK = Unterkategorie) |
| **Definition** | Genaue Beschreibung, was die Kategorie umfasst |
| **Ankerbeispiel** | Typisches Interviewzitat, das die Kategorie veranschaulicht |
| **Codierregel** (optional) | Abgrenzung zu anderen Kategorien, wann zugeordnet werden darf |

#### 7.2.2 Deduktive Kategorienentwicklung

**Wann:** Kategorien werden aus der Theorie abgeleitet (vor der Interviewdurchführung).

**Ablauf:**
1. Forschungsfrage auf Bestandteile untersuchen
2. Schlüsselbegriffe definieren und diskutieren
3. Theoriegeleitet Kategorien ableiten
4. Kategorien definieren und beschreiben
5. **Erprobung am Material** — 10–30% der Interviews probeweise codieren
6. **Ankerbeispiele sammeln** — typische Zitate identifizieren
7. **Codierregeln aufstellen** — bei Abgrenzungsschwierigkeiten
8. **In Schleifen arbeiten** — Kategorien ggf. verändern, umbenennen, neu justieren
9. Erneut am Material testen, bis keine Änderungen mehr nötig

**Wiederholte Überprüfung:** Kategorien müssen ggf. mehrfach überarbeitet werden. Das Arbeiten in Schleifen ist normaler Bestandteil des Forschungsprozesses.

#### 7.2.3 Induktive Kategorienentwicklung

**Wann:** Kategorien werden aus dem Material selbst entwickelt (nach der Datenerhebung). Typischerweise für Unterkategorien.

**Ablauf:**

```
SCHRITT A: Codiereinheit festlegen
  → Wie viel Text darf/muss codiert werden?
  → Empfehlung: Sinneinheiten, mindestens ein Satz

SCHRITT B: Material durcharbeiten
  → Alle relevanten Textstellen markieren

SCHRITT C: Paraphrasieren
  → Text knapp, inhaltlich beschränkt umschreiben
  → Füllwörter, Ausschmückungen entfernen
  → Auf einheitlicher Sprachebene formulieren
  → Bleibt nah am Originaltext

SCHRITT D: Generalisieren
  → Paraphrasen auf abstrakteres Sprachniveau heben
  → Von Alltagssprache zur Wissenschaftssprache
  → Inhaltliche Aussage bleibt erhalten

SCHRITT E: Reduktion / Subsumtion (1. Reduktion)
  → Redundante Paraphrasen streichen
  → Vorsicht: wirklich gleiche Aussage? Immer am Original prüfen

SCHRITT F: Reduktion (2. Reduktion)
  → Mehrere Paraphrasen zu einer zusammenfassen:
    • Gleiche/similar Aussagen → Bündelung
    • Mehrere Aussagen zu einem Gegenstand → Konstruktion/Integration
    • Gleicher Gegenstand, verschiedene Aussagen → Konstruktion/Integration

SCHRITT G: Kategorien bilden
  → Verdichtung zu Kategorien
  → Rücküberprüfung am Originaltext: Sind alle Paraphrasen abgedeckt?
```

#### 7.2.4 Kombination deduktiv + induktiv (empfohlen)

| Ebene | Herkunft | Zeitpunkt |
|-------|----------|-----------|
| **Oberkategorien** | Deduktiv (aus Theorie) | Vor Interviews |
| **Unterkategorien** | Induktiv (aus Material) | Nach Interviews |

**Wichtig:** Auch neue Oberkategorien können induktiv entstehen, wenn sich im Material Aspekte zeigen, die in der Theorie nicht bedacht wurden.

#### 7.2.5 Qualitätskriterien für Kategorien

- [ ] **Weder zu fein noch zu grob** — aussagekräftige Ergebnisse
- [ ] **Trennschärfe** — eindeutige Zuordnung möglich (durch Codierregeln)
- [ ] **Forschungsbezug** — jede Kategorie bezieht sich auf die Forschungsfrage
- [ ] **Materialprüfung** — an 10–50% der Interviews überprüft
- [ ] **Sättigung** — keine neuen Kategorien bei weiterem Materialdurchlauf

#### 7.2.6 Kategoriensystem-Vorlage

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ KATEGORIENSYSTEM: [Projekttitel]                                            │
├──────────┬──────────────┬──────────────────┬────────────────┬───────────────┤
│ Code     │ Definition   │ Ankerbeispiel    │ Codierregel    │ Quelle       │
├──────────┼──────────────┼──────────────────┼────────────────┼───────────────┤
│ OK 1     │ ...          │ "..." (I1, Z45)  │ ...            │ Theorie X    │
│ UK 1.1   │ ...          │ "..." (I2, Z12)  │ ...            │ induktiv     │
│ UK 1.2   │ ...          │ "..." (I3, Z78)  │ ...            │ induktiv     │
│ OK 2     │ ...          │ "..." (I1, Z90)  │ ...            │ Theorie Y    │
└──────────┴──────────────┴──────────────────┴────────────────┴───────────────┘
```

### 7.3 SCHRITT 3: CODIEREN DER INTERVIEWS

**Ziel:** Alle relevanten Textstellen aller Interviews den Kategorien zuordnen.

**Vorgehen:**
1. **Komplettes Kategoriensystem** liegt in finaler Form vor
2. **Zeile für Zeile** jedes Interview durcharbeiten
3. Relevante Textstellen einer oder mehreren Kategorien zuordnen
4. **Mehrfachcodierung** möglich — bei Häufung aber Trennschärfe prüfen

**Allgemeine Codierregeln (Kuckartz et al., 2008):**
- Codiert werden **Sinneinheiten**, aber mindestens ein Satz
- Ganze Absätze (ggf. inkl. einleitender Frage) sind möglich
- **Gleiche Fakteninformationen** innerhalb eines Interviews nur einmal codieren
- Ausnahme bei Einstellungen, Motiven, subjektiven Sichtweisen

**Codier-Methoden:**
| Methode | Vorteil | Nachteil |
|---------|---------|----------|
| **Papier + Buntstifte** | Intensiv, kein Software-Lernaufwand | Unübersichtlich bei vielen Interviews |
| **MAXQDA** | Professionell, Codebaum | Kostenpflichtig, Einarbeitung |
| **ATLAS.ti** | Probeversion, viele Funktionen | Einarbeitungszeit |
| **Excel/Tabelle** | Übersichtlich, einfach | Manuelle Sortierung |

**Qualitätssicherung beim Codieren (Pflicht, programmatisch prüfen):**
- Jede Textstelle (Ankerbeispiel **und** Codiertabelle-Zitat) automatisch gegen das extrahierte Transkript verifizieren: normalisierten Text (alle Whitespace-Folgen -> ein Leerzeichen) per Substring-Test suchen und nur Treffer ausliefern. Nie Zitate aus dem Gedächtnis schreiben.
- **PAGE-Marker-Falle:** Werden PDF-Seiten per pymupdf mit Markern wie `=== PAGE n ===` in den TXT-Export eingefügt, zerbricht jedes Zitat über einen Seitenumbruch. Marker vor der Normalisierung entfernen, sonst entstehen falsche "nicht gefunden"-Meldungen.
- **Groß-/Kleinschreibung** am Satzanfang ist die häufigste echte Abweichung: Zitat exakt aus dem Transkript kopieren, nicht aus dem Gedächtnis.
- Verbleibende Fehltreffer einzeln im Transkript nachschlagen (grep) und korrigieren; erst ausliefern, wenn 0 Abweichungen gemeldet werden.
- **Umlaut-Falle bei ASCII-Datenmodellen:** Werden Datentabellen in ASCII (ue/ae/oe/ss) gepflegt, ist eine globale Rueckkonvertierung unsicher — sie zerstört Woerter wie Steuerung -> Steürung (eue), Quelle -> Qülle (ue nach Qu), Betriebsstunden -> Betriebßtunden, Betrachtungsfrequenz -> Betrachtungsfreqünz, müssen -> müßen. Entweder Woerterbuch pro Wort oder globale Ersetzung mit Schutzliste (Prozess, Masse, Aussage, muss, dass, Mess, Klass, aktuell, genau, neue) plus Korrekturliste (Steuer, Quelle, Frequenz, müss, manuell). Auch englische Fachbegriffe schützen (Business, Success), sonst entstehen "Busineß"/"Succeß". Danach alle Woerter mit ä/ö/ü/ß im Ergebnis auflisten und sichten.

### 7.4 SCHRITT 4: KATEGORIENBASIERT AUSWERTEN

**Ziel:** Von der Fülle codierter Textstellen zu generalisierbaren, wissenschaftlichen Aussagen.

#### 7.4.1 Vier Teilschritte

**1. Zusammenfassung der Textstellen je Kategorie**
- Alle Textstellen einer Kategorie aufmerksam lesen und vergleichen
- Auffälligkeiten, Muster, erste Erklärungsversuche in Memos festhalten
- Ggf. Kategorien nachjustieren (zu fein/grob → anpassen, umcodieren)

**2. Beschreibung der Ergebnisse je Kategorie**
- Kernaussagen jeder Kategorie wissenschaftlich beschreiben
- Von Alltagssprache zur Wissenschaftssprache "übersetzen"
- Fachterminologie der zugrundeliegenden Theorien nutzen
- Ankerzitate einweben (Befragte selbst zu Wort kommen lassen)
- Bei vielen Kategorien: **Schlüsselkategorien** priorisieren

**3. Interpretative Einordnung**
- Ergebnisse in theoretischen Kontext einordnen
- Theorien, Modelle, Konzepte als Interpretationsfolie nutzen
- Zusammenhänge zwischen Kategorien herausarbeiten
- Visualisierungen (Schaubilder, Tabellen) einsetzen

**4. Zusammenfassende Diskussion**
- Forschungsfrage beantworten
- Ergebnisse zusammenführen
- Ggf. neue Hypothesen/Thesen formulieren

#### 7.4.2 Interpretationsfallen vermeiden

| Falle | Lösung |
|-------|--------|
| **Anonymität verletzen** | Ergebnisse so beschreiben, dass keine Rückschlüsse möglich |
| **Stereotype reproduzieren** | Rückgriff auf Theorien; Geschlecht, Herkunft etc. reflektieren |
| **Quantifizierungen** | Keine "50% der Befragten sagen..." bei n < 20 |
| **Reine Nacherzählung** | Nicht nur Gesagtes wiedergeben, sondern generalisieren |
| **Überinterpretation** | Interpretation immer am Text belegbar halten |

---

## 8. GÜTEKRITERIEN QUALITATIVER FORSCHUNG

### 8.1 Verfahrensdokumentation
- Jeden Schritt des Forschungsprozesses dokumentieren
- Kategorienentwicklung transparent beschreiben (deduktiv/induktiv/Kombination)
- Codierregeln und -entscheidungen offenlegen

### 8.2 Regelgeleitetheit
- Systematisches Vorgehen nach festgelegten Regeln
- Nachvollziehbarkeit für Leser:innen

### 8.3 Nähe zum Gegenstand
- Forschung in der Lebenswelt der Befragten
- Alltagssprache der Interviewten ernst nehmen

### 8.4 Kommunikative Validierung
- Ergebnisse mit Befragten oder Forscher:innenteam rückkoppeln
- Interpretationen im Diskurs absichern

### 8.5 Triangulation
- Mehrere Perspektiven: verschiedene Theorien, Methoden, Forschende
- Erhöht die Belastbarkeit der Ergebnisse

---

## 9. AUFBAU EINER EMPIRISCHEN ARBEIT

```
1. EINLEITUNG
   • Forschungsthema, Relevanz, Fragestellung
   • Aufbau der Arbeit

2. THEORETISCHER HINTERGRUND
   • Forschungsstand
   • Theoretische Konzepte
   • Deduktive Kategorien (als Grundlage für Leitfaden)

3. METHODISCHES VORGEHEN
   • Forschungsdesign begründen
   • Sampling / Feldzugang
   • Leitfadenentwicklung
   • Interviewdurchführung
   • Transkription (mit Systemangabe)
   • Auswertungsmethode (Qualitative Inhaltsanalyse nach Mayring)
   • Kategoriensystem (mit Definitionen, Ankerbeispielen, Codierregeln)

4. ERGEBNISSE
   • Kategorienbasierte Darstellung
   • Pro Kategorie: Zusammenfassung → Beschreibung → Interpretation
   • Ankerzitate einweben

5. DISKUSSION
   • Zusammenführung der Ergebnisse
   • Beantwortung der Forschungsfrage
   • Einordnung in Theoriediskurs
   • Methodische Reflexion (Limitationen, Gütekriterien)
   • Ausblick / offene Fragen

6. FAZIT
```

---

## 10. CODIER-TABELLE (ARBEITSVORLAGE)

### 10.1 Paraphrasierungs-Tabelle

| Interview/Zeile | Originaltext | Paraphrase | Generalisierung | Reduktion/Subsumtion |
|-----------------|-------------|------------|-----------------|---------------------|
| I1 / 45-48 | "..." | ... | ... | OK 1 → UK 1.1 |
| I2 / 12-15 | "..." | ... | ... | OK 1 → UK 1.1 |
| I3 / 78-82 | "..." | ... | ... | OK 2 |

### 10.2 Gefülltes Kategoriensystem (Ergebnis)

| Kategorie | Codierte Textstellen (mit Quellenangabe) | Zusammenfassung |
|-----------|------------------------------------------|-----------------|
| OK 1 | I1, Z45-48; I2, Z12-15; I3, Z78-82; ... | ... |
| UK 1.1 | I1, Z45-48; I2, Z12-15 | ... |
| OK 2 | I3, Z78-82; I4, Z34-40 | ... |

---

## 11. PITFALLS & HÄUFIGE FEHLER

| Fehler | Korrektur |
|--------|-----------|
| **Forschungsfrage zu breit** | Stärker eingrenzen, auf Kernaspekt fokussieren |
| **Leitfaden ohne Pretest** | Mindestens 1 Probeinterview durchführen |
| **Zu viele Suggestivfragen** | Durch Erzählaufforderungen ersetzen |
| **Keine Memos geführt** | Sofort nach jedem Lesedurchgang Memo anlegen |
| **Kategorien nicht trennscharf** | Codierregeln einführen, Definitionen schärfen |
| **Zu frühe Reduktion** | Erst paraphrasieren, dann generalisieren, dann reduzieren |
| **Quantifizierung bei n < 20** | Qualitative Aussagen ("viele", "einige", "vereinzelt") verwenden |
| **Nacherzählung statt Interpretation** | Theorie als Interpretationsfolie nutzen |
| **Keine Methodenreflexion** | Eigene Rolle, Limitationen und Fehler transparent machen |
| **Transkription zu grob** | Mindestens Kuckartz-System einhalten |

---

## 12. WEITERFÜHRENDE LITERATUR (aus dem TH Köln Skript)

- Mayring, P. (2010). *Qualitative Inhaltsanalyse. Grundlagen und Techniken* (11. Aufl.). Beltz.
- Mayring, P. & Gahleitner, S. B. (2010). Qualitative Inhaltsanalyse. In K. Bock & I. Miethe (Hrsg.), *Handbuch Qualitative Methoden in der Sozialen Arbeit* (S. 295–304). Budrich.
- Kuckartz, U. et al. (2008). *Qualitative Evaluation. Der Einstieg in die Praxis* (2. Aufl.). VS Verlag.
- Helfferich, C. (2011). *Die Qualität qualitativer Daten. Manual für die Durchführung qualitativer Interviews* (4. Aufl.). VS Verlag.
- Gläser, J. & Laudel, G. (2010). *Experteninterviews und qualitative Inhaltsanalyse* (4. Aufl.). VS Verlag.
- Flick, U. (2007). *Qualitative Sozialforschung. Eine Einführung*. Rowohlt.

---

## 13. VERWENDUNG DIESES SKILLS

**Wann laden:**
- Bei der Analyse von Interviewtranskripten
- Bei der Erstellung eines Forschungskonzepts mit Leitfadeninterviews
- Bei der Entwicklung eines Kategoriensystems (deduktiv/induktiv)
- Bei der Verschriftlichung empirischer Ergebnisse
- Bei der Bewertung/Review qualitativer Forschungsarbeiten

**Integration mit anderen Skills:**
- `methodological-qualitative-researcher`: Enthält die grundlegende Mayring-Methodik (dieser Skill ist die erweiterte TH Köln Version)
- `methodological-quantitative-analyst`: Für mixed-methods Ansätze mit quantitativen Anteilen
- `universal-document-architect-&-synthesizer`: Für die finale Verschriftlichung der Ergebnisse
