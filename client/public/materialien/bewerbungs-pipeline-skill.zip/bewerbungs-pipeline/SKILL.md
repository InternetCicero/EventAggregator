---
name: "bewerbungs-pipeline"
description: "Bewerbungs-Pipeline für {{VORNAME NACHNAME}} ({{AUSGABESPRACHE}}). Nutzen bei Stellenlink/-text, \"bewirb mich auf …\", \"CV anpassen\", \"Anschreiben\", \"Interview-Training\" oder wenn der Bewerbungs-Tracker (Excel) gescannt werden soll. Ablauf Stellenanalyse → CV-Matching → Dokumente → Fragen-Training."
---

# Bewerbungs-Pipeline ({{AUSGABESPRACHE}})

> **Vorlage.** Alles in `{{DOPPELTEN GESCHWEIFTEN KLAMMERN}}` ist ein Platzhalter und muss vor der Nutzung durch deine eigenen Angaben ersetzt werden. Der Abschnitt "Einrichtung" erklärt, was wohin gehört. Wenn du fertig bist, lösche den Abschnitt "Einrichtung" und diesen Hinweis.

Alle Outputs auf {{AUSGABESPRACHE}} (auch bei Stellenanzeigen in anderer Sprache). Dicht, keine Prosa-Erklärungen. Nichts wird gesendet, nur Entwürfe.

## Einrichtung (einmalig, danach löschen)

| Platzhalter | Was einzutragen ist |
|---|---|
| `{{VORNAME NACHNAME}}` | Dein Name, wie er im CV steht |
| `{{AUSGABESPRACHE}}` | Sprache deiner Bewerbungsunterlagen, z. B. Deutsch oder Englisch |
| `{{VERFUEGBAR_AB}}` | Frühester Eintritt, z. B. "Oct. 2027". Entfernen, falls du jederzeit verfügbar bist |
| `{{ZIELROLLEN}}` | Rollen/Branchen, auf die du dich bewirbst, z. B. Beratung, Produktmanagement, Finance |
| `{{FACHGEBIETE}}` | Fachliche Felder für das Training (Abschnitt Schritt 4) |
| `{{CV_BASIS_DESIGN}}` | Name und ID deines Master-CVs im Designtool (oder Pfad zur Master-Datei) |
| `{{TRACKER_DATEI}}` | Name deines Bewerbungs-Trackers (Excel) |
| MASTER-PROFIL | Deine Stationen als Bausteine (Format unten) |
| BESTÄTIGTE FAKTEN | Zahlen, die du selbst geprüft hast |
| STIL-REFERENZ | 3 selbst geschriebene Anschreiben |

Tipp: Fülle zuerst das MASTER-PROFIL und lass dir danach eine Stellenanalyse (Schritt 1) zu einer echten Anzeige geben, um zu testen, ob alles passt.

## Regeln (gelten in jedem Schritt)
1. **Fakten-Guard:** Nur Fakten und Zahlen aus dem MASTER-PROFIL unten. Neue Zahl oder Behauptung nötig → nachfragen, nie schätzen.
2. **Verfügbarkeit:** {{VERFUEGBAR_AB_REGEL, z. B. "Bewerbungen auf Vollzeitstellen erst ab <Datum>; im Anschreiben den Eintritt ab <Datum> nennen" oder "keine Einschränkung"}}.
3. **Bestätigungs-Checkpoint** nach Schritt 2 (Matching), bevor Dokumente gebaut werden.
4. Bei Tracker-Kontakt (Netzwerk) → Referral-Nachricht vorschlagen.
5. **Vertraulichkeit:** Kunden und Projekte im CV pseudonymisieren (z. B. "a B2B software client"), sofern keine Freigabe zur Namensnennung vorliegt.

## Schritt 1: Stellenanalyse
Input: Link (Seite abrufen, bei Login-Wand im Browser öffnen) oder Text. Output als Tabelle:
- Rolle, Firma, Standort, Frist, Sprache
- Must-have / Nice-to-have (je Zeile ein Kriterium)
- Keywords (10 max.) und Firmenton (1 Satz)
- Tier laut Tracker (falls vorhanden), bekannter Kontakt
- Red Flags (z. B. Abschluss gefordert, den du nicht hast, Muttersprache, Aufenthaltsstatus, Startdatum vor {{VERFUEGBAR_AB}})

## Schritt 2: CV-Matching
- Pro Must-have: Abdeckung (voll / teilweise / Lücke) + passender Baustein-ID (z. B. D2, A1)
- Match-Score = Anteil voll abgedeckter Must-haves in %
- Top 6 Bausteine in Reihenfolge für den CV, Rest weglassen
- Lücken: ehrlich benennen, Gegenstrategie (Framing aus vorhandenem Baustein, nie erfinden)
- Änderungsliste: Zeile alt → neu (Reihenfolge, Verben, Keywords)
- **STOPP:** Freigabe holen.

## Schritt 3: Dokumente (fixes Layout)
**CV:** Basis-Design kopieren ({{CV_BASIS_DESIGN}}), Titel "CV {{VORNAME NACHNAME}} - <Firma>", Text ersetzen. Layout nie ändern. 1 Seite, Bullets max. 2 Zeilen, Format: Verb + Ergebnis + Metrik. Vor dem Kopieren den aktuellen Stand der Basis lesen, denn sie wird manuell weiterentwickelt. Reihenfolge der Sections: {{SECTION_REIHENFOLGE, z. B. Professional Experience vor Education}}.

**Anschreiben:** Struktur, max. 250 Wörter, 1 Seite:
1. Hook: konkreter Firmenbezug (Projekt, Praxis, Aussage), kein "I am writing to apply"
2. Beweis 1: stärkster Baustein zum wichtigsten Must-have (Metrik)
3. Beweis 2: zweiter Baustein oder Lücken-Framing
4. Abschluss: Beitrag, den du in der Rolle leistest{{, Verfügbarkeit ab {{VERFUEGBAR_AB}}}}

Stil: aus STIL-REFERENZ unten ableiten (Satzlänge, Ton, Einstiege). Solange dort keine 3 Briefe stehen → bitten, sie einzufügen. Layout-Template einmal festlegen lassen, dann fix.

**Optional:** Referral-Nachricht (LinkedIn/Mail), max. 80 Wörter, als Entwurf.

## Schritt 4: Fragen-Training ({{TRAININGS_SCHWERPUNKT, z. B. Case und Fachliches}})
- Fragenkatalog zur Stelle: ca. 70 % fachlich, 30 % Fit
- Fachliche Felder: {{FACHGEBIETE, z. B. Marktgrößen-Schätzung, Profitability, Finance-Basics (DCF, Multiples), Branchenwissen deiner Zielrolle}}
- Case-Format (falls relevant): Case in 3 Sätzen vorgeben → Strukturierung durch dich → Feedback: Struktur (MECE), Hypothese, Mathe, Synthese
- Fit-Fragen: Antworten nach STAR aus Bausteinen, je Frage 1 Hauptbaustein
- Training: eine Frage pro Nachricht, kurzes Feedback (max. 5 Zeilen: stark / schwach / Besser-Formulierung), nach 5 Fragen Score und nächster Fokus

## Excel-Modus
Tracker-Datei ({{TRACKER_DATEI}}) anbinden. Spalten durchgehen: Firma, Rolle, Kontakt, Frist, Status, Referral. Zeilen mit Status "offen" und passender Frist abarbeiten: Stellenseite scannen → Schritt 1 als Kurzzeile (Match-Score grob, Frist, Link) in die Notizen-Spalte. Vollpaket (Schritt 2–3) nur auf Zuruf pro Zeile. Original nie überschreiben, mit Kopie arbeiten.

## Review vor Ausgabe
- Jede Zahl im Dokument im Profil auffindbar?
- CV 1 Seite, Anschreiben ≤ 250 Wörter?
- Keine Wiederholung zwischen CV und Anschreiben (Anschreiben vertieft, wiederholt nicht)
- Keywords der Stelle sinnvoll abgedeckt, ohne Stuffing

---

# MASTER-PROFIL (Quelle: {{CV_BASIS_DESIGN}} = Master; Stand {{DATUM}})

**Kontakt:** {{VORNAME NACHNAME}} · {{E-MAIL}} · {{TELEFON}} · {{ORT, LAND}} · {{LINKEDIN-URL}}

**Education**
- {{HOCHSCHULE}}, {{ABSCHLUSS, FACH}} ({{NOTE}}), {{VON – BIS}}, {{ORT}}. {{Auslandssemester o. Ä.}}
- {{SCHULE}}, {{ABSCHLUSS}}, {{BESONDERHEITEN, z. B. Leistungskurse, Abschlussarbeit}}, {{VON – BIS}}

**Bausteine** (ID · Aussage · Tags)
Jeder Baustein ist **eine** belegbare Aussage mit Metrik. Die ID bleibt stabil, damit das Matching darauf verweisen kann. Pro Station ein Buchstabe, dann nummerieren.

{{ARBEITGEBER/ROLLE 1}}, {{ROLLE}}, {{ORT}}, {{VON – BIS}}
- A1 · {{Verb + Ergebnis + Metrik}} · {{Tag, Tag}}
- A2 · {{…}} · {{…}}

{{ARBEITGEBER/ROLLE 2}}, {{ROLLE}}, {{ORT}}, {{VON – BIS}}
- B1 · {{…}} · {{…}}

{{EHRENAMT / VEREIN / PROJEKT}}, {{ROLLE}}, {{VON – BIS}}
- C1 · {{…}} · {{…}}

(Beliebig viele Stationen. Bausteine, die nur in einer Sprachversion oder nur bei Bedarf genutzt werden, mit "nur …" kennzeichnen.)

**Skills:** {{SKILL, SKILL, …}}
**Languages:** {{SPRACHE (NIVEAU), …}}
**Interests:** {{INTERESSEN, ggf. mit Hinweis, für welche Rollen sie genutzt werden}}
**Weitere Bausteine, nicht im CV:** {{ZERTIFIKATE, PROJEKTE, … die bei Bedarf einsetzbar sind}}

**Ziele/Kontext:** {{ZIELROLLEN, ZEITRAUM, STANDORTE, BESONDERHEITEN}}

# BESTÄTIGTE FAKTEN ({{DATUM}})
Zahlen und Angaben, die du selbst geprüft hast; sie haben Vorrang, falls sie dem Profil widersprechen.
1. {{z. B. Note: "Grade 2.0", ohne Zusatz zur Skala}}
2. {{z. B. Einsparung: €500 costs annually}}
3. {{…}}

# STIL-REFERENZ ANSCHREIBEN
Füge hier 3 selbst geschriebene Anschreiben ein. Ältere oder in anderer Sprache verfasste Briefe nicht als Stilquelle nutzen.

1. {{ANSCHREIBEN 1}}
2. {{ANSCHREIBEN 2}}
3. {{ANSCHREIBEN 3}}
